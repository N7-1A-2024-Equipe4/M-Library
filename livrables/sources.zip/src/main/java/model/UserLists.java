package model;

import java.util.List;

/**
 * Models the movie lists of an user.
 */
public class UserLists {

    private User user;

    private List<MovieLibrary> lists;
}
