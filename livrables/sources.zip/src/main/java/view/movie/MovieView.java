package view.movie;

import com.intellij.uiDesigner.core.GridConstraints;
import com.intellij.uiDesigner.core.GridLayoutManager;
import com.intellij.uiDesigner.core.Spacer;
import controller.MovieController;
import dao.ReviewDAO;
import model.Library;
import model.Movie;
import model.Person;
import model.Review;
import model.User;
import org.apache.commons.lang3.StringUtils;
import service.LibraryService;
import service.MovieService;
import service.SessionService;
import utils.image.ImageUtil;
import utils.TimeUtils;
import view.View;

import javax.swing.*;
import javax.swing.border.TitledBorder;
import javax.swing.plaf.FontUIResource;
import javax.swing.text.StyleContext;
import java.awt.*;
import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.stream.Collectors;

public class MovieView implements View {
    private final int WIDTH = 200;
    private final int HEIGHT = 300;

    private final MovieController controller;
    private Movie movie;

    private JPanel panel;
    private JLabel movieImage;
    private JLabel movieTitle;
    private JLabel movieGenre;
    private JLabel movieDuration;
    private JLabel movieRating;
    private JLabel movieSynopsis;
    private JLabel movieDirectors;
    private JPanel movieCastingPanel;
    private JButton addAReview;
    private JPanel reviewPanel;
    private JComboBox addMovieToLibraryComboBox;
    private JTextField addMovieToLibraryNoteText;
    private JLabel addMovieToLibraryLabel;
    private JButton addMovieToLibraryButton;
    private Map<String, Library> libraryMap;

    private final MovieService movieService;
    private final ReviewDAO reviewDAO;

    private final LibraryService libraryService;
    private final SimpleDateFormat dateFormat;

    public MovieView() {
        this.controller = new MovieController(this);
        this.movieService = new MovieService();
        this.reviewDAO = new ReviewDAO();
        this.dateFormat = new SimpleDateFormat("yyyy-MM-dd");

        addAReview.addActionListener(e -> {
            openReviewForm();
        });
        this.libraryService = new LibraryService();
        this.libraryMap = new HashMap<>();
        this.addMovieToLibraryButton.addActionListener(e -> controller.addMovieToLibraryAction(
                libraryMap.get(addMovieToLibraryComboBox.getSelectedItem()),
                movie.getId(),
                addMovieToLibraryNoteText.getText()
        ));
    }

    @Override
    public JPanel getPanel() {
        return panel;
    }

    @Override
    public void refresh(Integer movieID) {
        try {
            Movie fetchedMovie = movieService.getMovieById(movieID);
            movie = fetchedMovie;

            if (fetchedMovie.getPoster() != null) {
                movieImage.setIcon(new ImageIcon(ImageUtil.getScaledImage(fetchedMovie.getPoster().getImage(), WIDTH, HEIGHT)));
            }

            movieTitle.setText(fetchedMovie.getTitle());
            movieGenre.setText(StringUtils.capitalize(fetchedMovie.getGenre().toString().toLowerCase()));
            movieDuration.setText(TimeUtils.formatDuration(fetchedMovie.getDuration()));
            movieSynopsis.setText(fetchedMovie.getSynopsis());
            movieRating.setText(Float.toString(fetchedMovie.getRating()));
            movieDirectors.setText(formatDirectors(fetchedMovie.getDirectors()));

            populateCastingPanel(fetchedMovie.getActors());

            List<Review> reviews = reviewDAO.getByMovieId(movieID);
            populateReviewPanel(reviews);
            setupAddToLibrary();

        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }

    private void setupAddToLibrary() throws SQLException {
        if (SessionService.isLoggedIn()) {
            addMovieToLibraryLabel.setText("Add a note to go along with the movie in your library:");
            addMovieToLibraryComboBox.setVisible(true);
            addMovieToLibraryButton.setVisible(true);
            addMovieToLibraryNoteText.setVisible(true);
            addMovieToLibraryNoteText.setText("");
            List<Library> libraries = libraryService.getByUserIdComplete(SessionService.getUser().getId());

            // Add movie to library
            addMovieToLibraryComboBox.removeAllItems();
            for (Library library : libraries) {
                if (library.getMovies().stream().noneMatch(m -> m.getId() == movie.getId())) {
                    libraryMap.put(library.getName(), library);
                    addMovieToLibraryComboBox.addItem(library.getName());
                }
            }
            addMovieToLibraryComboBox.setSelectedIndex(-1);
        } else {
            addMovieToLibraryLabel.setText("Please log in order to add movie to library");
            addMovieToLibraryComboBox.setVisible(false);
            addMovieToLibraryButton.setVisible(false);
            addMovieToLibraryNoteText.setVisible(false);
        }
    }

    private String formatDirectors(List<Person> directors) {
        if (directors == null || directors.isEmpty()) {
            return "Unknown";
        }
        return directors.stream()
                .map(director -> director.getFirstName() + " " + director.getLastName())
                .collect(Collectors.joining(", "));
    }

    private String formatActorDetails(Person actor) {
        StringBuilder details = new StringBuilder();
        details.append(actor.getFirstName()).append(" ").append(actor.getLastName());
        if (actor.getDateOfBirth() != null) {
            details.append(" (").append(dateFormat.format(actor.getDateOfBirth()));
            if (actor.getDateOfDeath() != null) {
                details.append(" - ").append(dateFormat.format(actor.getDateOfDeath()));
            }
            details.append(")");
        }
        return details.toString();
    }

    private void populateCastingPanel(List<Person> actors) {
        movieCastingPanel.removeAll();
        movieCastingPanel.setLayout(new BoxLayout(movieCastingPanel, BoxLayout.Y_AXIS));

        Font synopsisFont = movieSynopsis.getFont();
        if (actors == null || actors.isEmpty()) {
            JLabel noActorsLabel = new JLabel("No actors available");
            noActorsLabel.setFont(synopsisFont);
            movieCastingPanel.add(noActorsLabel);
        } else {
            for (Person actor : actors) {
                JLabel actorLabel = new JLabel(formatActorDetails(actor));
                actorLabel.setFont(synopsisFont);
                movieCastingPanel.add(actorLabel);
                movieCastingPanel.add(Box.createVerticalStrut(3));
            }
        }

        movieCastingPanel.revalidate();
        movieCastingPanel.repaint();
    }

    private void populateReviewPanel(List<Review> reviews) {
        reviewPanel.removeAll();
        reviewPanel.setLayout(new BoxLayout(reviewPanel, BoxLayout.Y_AXIS));

        if (reviews == null || reviews.isEmpty()) {
            JLabel noReviewsLabel = new JLabel("No reviews available");
            Font synopsisFont = movieSynopsis.getFont();
            noReviewsLabel.setFont(synopsisFont);
            reviewPanel.add(noReviewsLabel);
        } else {
            for (Review review : reviews) {
                ReviewView reviewView = new ReviewView(review);
                reviewPanel.add(reviewView);
                reviewPanel.add(Box.createVerticalStrut(3));
            }
        }

        reviewPanel.revalidate();
        reviewPanel.repaint();
    }


    private void openReviewForm() {
        if (SessionService.isLoggedIn()) {
            User currentUser = SessionService.getUser();

            JFrame reviewFrame = new JFrame("Submit a Review");
            reviewFrame.setSize(300, 200);
            reviewFrame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);

            JPanel reviewPanel = new JPanel();
            reviewPanel.setLayout(new BoxLayout(reviewPanel, BoxLayout.Y_AXIS));

            JTextField reviewField = new JTextField();
            JSpinner ratingSpinner = new JSpinner(new SpinnerNumberModel(0.0, 0.0, 10.0, 0.1));

            JButton submitButton = new JButton("Submit");

            submitButton.addActionListener(e -> {
                Number ratingValue = (Number) ratingSpinner.getValue();
                float rating = ratingValue.floatValue();
                controller.submitReview(reviewField.getText(), rating, currentUser, movie);
                refresh(movie.getId());

                reviewFrame.setVisible(false);
            });

            reviewPanel.add(new JLabel("Review:"));
            reviewPanel.add(reviewField);
            reviewPanel.add(new JLabel("Rating:"));
            reviewPanel.add(ratingSpinner);
            reviewPanel.add(submitButton);

            reviewFrame.add(reviewPanel);
            reviewFrame.setVisible(true);
        } else {
            JOptionPane.showMessageDialog(panel, "You need to be logged in to submit a review.");
        }
    }

    {
// GUI initializer generated by IntelliJ IDEA GUI Designer
// >>> IMPORTANT!! <<<
// DO NOT EDIT OR ADD ANY CODE HERE!
        $$$setupUI$$$();
    }

    /**
     * Method generated by IntelliJ IDEA GUI Designer
     * >>> IMPORTANT!! <<<
     * DO NOT edit this method OR call it in your code!
     *
     * @noinspection ALL
     */
    private void $$$setupUI$$$() {
        panel = new JPanel();
        panel.setLayout(new BorderLayout(0, 0));
        panel.setPreferredSize(new Dimension(-1, -1));
        panel.setVisible(true);
        final JScrollPane scrollPane1 = new JScrollPane();
        panel.add(scrollPane1, BorderLayout.CENTER);
        final JPanel panel1 = new JPanel();
        panel1.setLayout(new GridLayoutManager(6, 1, new Insets(0, 0, 0, 0), -1, -1));
        scrollPane1.setViewportView(panel1);
        panel1.setBorder(BorderFactory.createTitledBorder(BorderFactory.createEmptyBorder(50, 100, 0, 0), null, TitledBorder.DEFAULT_JUSTIFICATION, TitledBorder.DEFAULT_POSITION, null, null));
        final JPanel panel2 = new JPanel();
        panel2.setLayout(new BorderLayout(0, 0));
        panel1.add(panel2, new GridConstraints(0, 0, 1, 1, GridConstraints.ANCHOR_CENTER, GridConstraints.FILL_BOTH, 1, 1, null, null, null, 0, false));
        final JPanel panel3 = new JPanel();
        panel3.setLayout(new GridLayoutManager(5, 1, new Insets(0, 10, 0, 0), -1, 2));
        panel3.setMinimumSize(new Dimension(-1, 100));
        panel2.add(panel3, BorderLayout.CENTER);
        movieTitle = new JLabel();
        Font movieTitleFont = this.$$$getFont$$$(null, Font.BOLD, 28, movieTitle.getFont());
        if (movieTitleFont != null) movieTitle.setFont(movieTitleFont);
        movieTitle.setText("Label");
        panel3.add(movieTitle, new GridConstraints(0, 0, 1, 1, GridConstraints.ANCHOR_WEST, GridConstraints.FILL_NONE, GridConstraints.SIZEPOLICY_CAN_GROW, GridConstraints.SIZEPOLICY_FIXED, null, null, null, 0, false));
        movieDuration = new JLabel();
        Font movieDurationFont = this.$$$getFont$$$(null, Font.PLAIN, 16, movieDuration.getFont());
        if (movieDurationFont != null) movieDuration.setFont(movieDurationFont);
        movieDuration.setText("Label");
        panel3.add(movieDuration, new GridConstraints(1, 0, 1, 1, GridConstraints.ANCHOR_WEST, GridConstraints.FILL_NONE, GridConstraints.SIZEPOLICY_CAN_GROW, GridConstraints.SIZEPOLICY_FIXED, null, null, null, 0, false));
        final JPanel panel4 = new JPanel();
        panel4.setLayout(new FlowLayout(FlowLayout.LEFT, 0, 0));
        panel3.add(panel4, new GridConstraints(3, 0, 1, 1, GridConstraints.ANCHOR_CENTER, GridConstraints.FILL_BOTH, GridConstraints.SIZEPOLICY_CAN_SHRINK | GridConstraints.SIZEPOLICY_CAN_GROW, GridConstraints.SIZEPOLICY_CAN_SHRINK | GridConstraints.SIZEPOLICY_CAN_GROW, null, null, null, 0, false));
        final JLabel label1 = new JLabel();
        Font label1Font = this.$$$getFont$$$(null, Font.BOLD, 16, label1.getFont());
        if (label1Font != null) label1.setFont(label1Font);
        label1.setText("Genre : ");
        panel4.add(label1);
        movieGenre = new JLabel();
        movieGenre.setAlignmentY(0.0f);
        Font movieGenreFont = this.$$$getFont$$$(null, Font.PLAIN, 16, movieGenre.getFont());
        if (movieGenreFont != null) movieGenre.setFont(movieGenreFont);
        movieGenre.setIconTextGap(0);
        movieGenre.setText("Label");
        movieGenre.setVerifyInputWhenFocusTarget(true);
        movieGenre.setVisible(true);
        panel4.add(movieGenre);
        final JPanel panel5 = new JPanel();
        panel5.setLayout(new GridLayoutManager(1, 1, new Insets(10, 10, 10, 10), -1, -1));
        panel5.setBackground(new Color(-14277082));
        panel3.add(panel5, new GridConstraints(4, 0, 1, 1, GridConstraints.ANCHOR_WEST, GridConstraints.FILL_NONE, GridConstraints.SIZEPOLICY_FIXED, GridConstraints.SIZEPOLICY_FIXED, null, null, null, 0, false));
        movieRating = new JLabel();
        movieRating.setBackground(new Color(-1));
        Font movieRatingFont = this.$$$getFont$$$(null, Font.BOLD, 22, movieRating.getFont());
        if (movieRatingFont != null) movieRating.setFont(movieRatingFont);
        movieRating.setForeground(new Color(-1));
        movieRating.setText("0.0");
        panel5.add(movieRating, new GridConstraints(0, 0, 1, 1, GridConstraints.ANCHOR_WEST, GridConstraints.FILL_NONE, GridConstraints.SIZEPOLICY_CAN_GROW, GridConstraints.SIZEPOLICY_FIXED, null, null, null, 0, false));
        final JPanel panel6 = new JPanel();
        panel6.setLayout(new FlowLayout(FlowLayout.LEFT, 0, 0));
        panel3.add(panel6, new GridConstraints(2, 0, 1, 1, GridConstraints.ANCHOR_CENTER, GridConstraints.FILL_BOTH, GridConstraints.SIZEPOLICY_FIXED, GridConstraints.SIZEPOLICY_FIXED, null, null, null, 0, false));
        final JLabel label2 = new JLabel();
        Font label2Font = this.$$$getFont$$$(null, Font.BOLD, 16, label2.getFont());
        if (label2Font != null) label2.setFont(label2Font);
        label2.setText("Directors : ");
        panel6.add(label2);
        movieDirectors = new JLabel();
        movieDirectors.setAlignmentY(0.0f);
        Font movieDirectorsFont = this.$$$getFont$$$(null, Font.PLAIN, 16, movieDirectors.getFont());
        if (movieDirectorsFont != null) movieDirectors.setFont(movieDirectorsFont);
        movieDirectors.setIconTextGap(0);
        movieDirectors.setText("Label");
        movieDirectors.setVerifyInputWhenFocusTarget(true);
        movieDirectors.setVisible(true);
        panel6.add(movieDirectors);
        final JPanel panel7 = new JPanel();
        panel7.setLayout(new GridLayoutManager(1, 1, new Insets(0, 0, 0, 0), -1, -1));
        panel2.add(panel7, BorderLayout.WEST);
        movieImage = new JLabel();
        movieImage.setText("");
        panel7.add(movieImage, new GridConstraints(0, 0, 1, 1, GridConstraints.ANCHOR_WEST, GridConstraints.FILL_NONE, GridConstraints.SIZEPOLICY_FIXED, GridConstraints.SIZEPOLICY_FIXED, null, null, null, 0, false));
        final JPanel panel8 = new JPanel();
        panel8.setLayout(new GridLayoutManager(3, 1, new Insets(0, 0, 0, 0), -1, -1));
        panel1.add(panel8, new GridConstraints(1, 0, 1, 1, GridConstraints.ANCHOR_CENTER, GridConstraints.FILL_BOTH, 1, 1, null, null, null, 0, false));
        panel8.setBorder(BorderFactory.createTitledBorder(BorderFactory.createEmptyBorder(10, 0, 0, 0), null, TitledBorder.DEFAULT_JUSTIFICATION, TitledBorder.DEFAULT_POSITION, null, null));
        final JLabel label3 = new JLabel();
        Font label3Font = this.$$$getFont$$$(null, Font.BOLD, 20, label3.getFont());
        if (label3Font != null) label3.setFont(label3Font);
        label3.setText("Synopsis");
        panel8.add(label3, new GridConstraints(0, 0, 1, 1, GridConstraints.ANCHOR_WEST, GridConstraints.FILL_NONE, GridConstraints.SIZEPOLICY_FIXED, GridConstraints.SIZEPOLICY_FIXED, null, null, null, 0, false));
        movieSynopsis = new JLabel();
        Font movieSynopsisFont = this.$$$getFont$$$(null, Font.PLAIN, 16, movieSynopsis.getFont());
        if (movieSynopsisFont != null) movieSynopsis.setFont(movieSynopsisFont);
        movieSynopsis.setRequestFocusEnabled(false);
        movieSynopsis.setText("<html><div style='width:500px;margin-top:10px'>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Phasellus nec dolor vehicula, consectetur metus at, sodales sapien. Maecenas vitae consectetur velit. Mauris commodo suscipit nibh. Mauris imperdiet dictum magna ac pellentesque. Fusce convallis eu dui id luctus. Maecenas vehicula porttitor quam.</div></html>");
        panel8.add(movieSynopsis, new GridConstraints(2, 0, 1, 1, GridConstraints.ANCHOR_WEST, GridConstraints.FILL_NONE, GridConstraints.SIZEPOLICY_FIXED, GridConstraints.SIZEPOLICY_FIXED, null, null, null, 0, false));
        final JPanel panel9 = new JPanel();
        panel9.setLayout(new GridLayoutManager(2, 1, new Insets(10, 0, 0, 0), -1, -1));
        panel1.add(panel9, new GridConstraints(2, 0, 1, 1, GridConstraints.ANCHOR_CENTER, GridConstraints.FILL_BOTH, 1, 1, null, null, null, 0, false));
        final JLabel label4 = new JLabel();
        Font label4Font = this.$$$getFont$$$(null, Font.BOLD, 20, label4.getFont());
        if (label4Font != null) label4.setFont(label4Font);
        label4.setText("Casting");
        panel9.add(label4, new GridConstraints(0, 0, 1, 1, GridConstraints.ANCHOR_WEST, GridConstraints.FILL_NONE, GridConstraints.SIZEPOLICY_FIXED, GridConstraints.SIZEPOLICY_FIXED, null, null, null, 0, false));
        movieCastingPanel = new JPanel();
        movieCastingPanel.setLayout(new GridLayoutManager(1, 1, new Insets(0, 0, 0, 0), -1, -1));
        panel9.add(movieCastingPanel, new GridConstraints(1, 0, 1, 1, GridConstraints.ANCHOR_CENTER, GridConstraints.FILL_BOTH, GridConstraints.SIZEPOLICY_CAN_SHRINK | GridConstraints.SIZEPOLICY_CAN_GROW, GridConstraints.SIZEPOLICY_CAN_SHRINK | GridConstraints.SIZEPOLICY_CAN_GROW, null, null, null, 0, false));
        final JPanel panel10 = new JPanel();
        panel10.setLayout(new GridLayoutManager(3, 1, new Insets(10, 0, 0, 0), -1, -1));
        panel1.add(panel10, new GridConstraints(4, 0, 1, 1, GridConstraints.ANCHOR_WEST, GridConstraints.FILL_NONE, GridConstraints.SIZEPOLICY_CAN_SHRINK | GridConstraints.SIZEPOLICY_CAN_GROW, GridConstraints.SIZEPOLICY_CAN_SHRINK | GridConstraints.SIZEPOLICY_CAN_GROW, null, null, null, 0, false));
        final JPanel panel11 = new JPanel();
        panel11.setLayout(new FlowLayout(FlowLayout.LEFT, 0, 0));
        panel10.add(panel11, new GridConstraints(1, 0, 1, 1, GridConstraints.ANCHOR_CENTER, GridConstraints.FILL_BOTH, GridConstraints.SIZEPOLICY_CAN_SHRINK | GridConstraints.SIZEPOLICY_CAN_GROW, GridConstraints.SIZEPOLICY_CAN_SHRINK | GridConstraints.SIZEPOLICY_CAN_GROW, null, null, null, 0, false));
        final JLabel label5 = new JLabel();
        Font label5Font = this.$$$getFont$$$(null, Font.BOLD, 20, label5.getFont());
        if (label5Font != null) label5.setFont(label5Font);
        label5.setText("<html><div style='margin-right:10px'>Reviews</div></html>");
        panel11.add(label5);
        addAReview = new JButton();
        addAReview.setText("Add a review");
        addAReview.putClientProperty("html.disable", Boolean.FALSE);
        panel11.add(addAReview);
        reviewPanel = new JPanel();
        reviewPanel.setLayout(new FlowLayout(FlowLayout.CENTER, 5, 5));
        panel10.add(reviewPanel, new GridConstraints(2, 0, 1, 1, GridConstraints.ANCHOR_CENTER, GridConstraints.FILL_BOTH, GridConstraints.SIZEPOLICY_CAN_SHRINK | GridConstraints.SIZEPOLICY_CAN_GROW, GridConstraints.SIZEPOLICY_CAN_SHRINK | GridConstraints.SIZEPOLICY_CAN_GROW, null, null, null, 0, false));
        final Spacer spacer1 = new Spacer();
        panel1.add(spacer1, new GridConstraints(5, 0, 1, 1, GridConstraints.ANCHOR_CENTER, GridConstraints.FILL_VERTICAL, 1, GridConstraints.SIZEPOLICY_WANT_GROW, null, null, null, 0, false));
        final JPanel panel12 = new JPanel();
        panel12.setLayout(new GridLayoutManager(5, 3, new Insets(0, 0, 0, 0), -1, -1));
        panel1.add(panel12, new GridConstraints(3, 0, 1, 1, GridConstraints.ANCHOR_CENTER, GridConstraints.FILL_BOTH, GridConstraints.SIZEPOLICY_CAN_SHRINK | GridConstraints.SIZEPOLICY_CAN_GROW, GridConstraints.SIZEPOLICY_CAN_SHRINK | GridConstraints.SIZEPOLICY_CAN_GROW, null, null, null, 0, false));
        final JPanel panel13 = new JPanel();
        panel13.setLayout(new FlowLayout(FlowLayout.LEFT, 0, 0));
        panel12.add(panel13, new GridConstraints(0, 0, 1, 2, GridConstraints.ANCHOR_CENTER, GridConstraints.FILL_BOTH, GridConstraints.SIZEPOLICY_CAN_SHRINK | GridConstraints.SIZEPOLICY_CAN_GROW, GridConstraints.SIZEPOLICY_CAN_SHRINK | GridConstraints.SIZEPOLICY_CAN_GROW, null, new Dimension(792, 34), null, 0, false));
        final JLabel label6 = new JLabel();
        Font label6Font = this.$$$getFont$$$(null, Font.BOLD, 20, label6.getFont());
        if (label6Font != null) label6.setFont(label6Font);
        label6.setText("<html><div style='margin-right:10px'>Add movie to library</div></html>");
        panel13.add(label6);
        addMovieToLibraryComboBox = new JComboBox();
        panel13.add(addMovieToLibraryComboBox);
        final Spacer spacer2 = new Spacer();
        panel12.add(spacer2, new GridConstraints(0, 2, 1, 1, GridConstraints.ANCHOR_CENTER, GridConstraints.FILL_HORIZONTAL, GridConstraints.SIZEPOLICY_WANT_GROW, 1, null, null, null, 0, false));
        addMovieToLibraryNoteText = new JTextField();
        addMovieToLibraryNoteText.setText("");
        panel12.add(addMovieToLibraryNoteText, new GridConstraints(2, 0, 1, 1, GridConstraints.ANCHOR_CENTER, GridConstraints.FILL_NONE, GridConstraints.SIZEPOLICY_CAN_SHRINK | GridConstraints.SIZEPOLICY_CAN_GROW, GridConstraints.SIZEPOLICY_CAN_SHRINK | GridConstraints.SIZEPOLICY_CAN_GROW, null, new Dimension(362, 54), null, 0, false));
        final Spacer spacer3 = new Spacer();
        panel12.add(spacer3, new GridConstraints(2, 1, 1, 1, GridConstraints.ANCHOR_CENTER, GridConstraints.FILL_HORIZONTAL, GridConstraints.SIZEPOLICY_WANT_GROW, 1, null, new Dimension(14, 54), null, 0, false));
        addMovieToLibraryButton = new JButton();
        addMovieToLibraryButton.setText("Add");
        panel12.add(addMovieToLibraryButton, new GridConstraints(3, 0, 1, 1, GridConstraints.ANCHOR_CENTER, GridConstraints.FILL_NONE, GridConstraints.SIZEPOLICY_CAN_SHRINK | GridConstraints.SIZEPOLICY_CAN_GROW, GridConstraints.SIZEPOLICY_CAN_SHRINK | GridConstraints.SIZEPOLICY_CAN_GROW, null, new Dimension(362, 34), null, 0, false));
        final Spacer spacer4 = new Spacer();
        panel12.add(spacer4, new GridConstraints(3, 1, 1, 1, GridConstraints.ANCHOR_CENTER, GridConstraints.FILL_HORIZONTAL, GridConstraints.SIZEPOLICY_WANT_GROW, 1, null, null, null, 0, false));
        final JPanel panel14 = new JPanel();
        panel14.setLayout(new BorderLayout(0, 0));
        panel12.add(panel14, new GridConstraints(4, 0, 1, 1, GridConstraints.ANCHOR_CENTER, GridConstraints.FILL_BOTH, GridConstraints.SIZEPOLICY_CAN_SHRINK | GridConstraints.SIZEPOLICY_CAN_GROW, GridConstraints.SIZEPOLICY_CAN_SHRINK | GridConstraints.SIZEPOLICY_CAN_GROW, null, null, null, 0, false));
        final JPanel panel15 = new JPanel();
        panel15.setLayout(new BorderLayout(0, 0));
        panel12.add(panel15, new GridConstraints(1, 0, 1, 1, GridConstraints.ANCHOR_CENTER, GridConstraints.FILL_BOTH, GridConstraints.SIZEPOLICY_CAN_SHRINK | GridConstraints.SIZEPOLICY_CAN_GROW, GridConstraints.SIZEPOLICY_CAN_SHRINK | GridConstraints.SIZEPOLICY_CAN_GROW, null, null, null, 0, false));
        addMovieToLibraryLabel = new JLabel();
        addMovieToLibraryLabel.setEnabled(true);
        Font addMovieToLibraryLabelFont = this.$$$getFont$$$(null, -1, 14, addMovieToLibraryLabel.getFont());
        if (addMovieToLibraryLabelFont != null) addMovieToLibraryLabel.setFont(addMovieToLibraryLabelFont);
        addMovieToLibraryLabel.setText("Label");
        panel15.add(addMovieToLibraryLabel, BorderLayout.CENTER);
    }

    /**
     * @noinspection ALL
     */
    private Font $$$getFont$$$(String fontName, int style, int size, Font currentFont) {
        if (currentFont == null) return null;
        String resultName;
        if (fontName == null) {
            resultName = currentFont.getName();
        } else {
            Font testFont = new Font(fontName, Font.PLAIN, 10);
            if (testFont.canDisplay('a') && testFont.canDisplay('1')) {
                resultName = fontName;
            } else {
                resultName = currentFont.getName();
            }
        }
        Font font = new Font(resultName, style >= 0 ? style : currentFont.getStyle(), size >= 0 ? size : currentFont.getSize());
        boolean isMac = System.getProperty("os.name", "").toLowerCase(Locale.ENGLISH).startsWith("mac");
        Font fontWithFallback = isMac ? new Font(font.getFamily(), font.getStyle(), font.getSize()) : new StyleContext().getFont(font.getFamily(), font.getStyle(), font.getSize());
        return fontWithFallback instanceof FontUIResource ? fontWithFallback : new FontUIResource(fontWithFallback);
    }

    /**
     * @noinspection ALL
     */
    public JComponent $$$getRootComponent$$$() {
        return panel;
    }

}
